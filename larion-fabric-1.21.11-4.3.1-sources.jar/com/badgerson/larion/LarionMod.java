package com.badgerson.larion;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import com.badgerson.larion.density_function_types.*;

public class LarionMod implements ModInitializer {

  @Override
  public void onInitialize() {

    // This method is invoked by the Fabric mod loader when it is ready
    // to load your mod. You can access Fabric and Common code in this
    // project.

    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "div"), Division.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "sqrt"), Sqrt.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "signum"), Signum.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "sine"), Sine.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "x"), XCoord.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "z"), ZCoord.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41160,
        class_2960.method_60655(Constants.MOD_ID, "flat_domain_warp"), FlatDomainWarp.CODEC.comp_640());
    class_2378.method_10230(class_7923.field_41158,
        class_2960.method_60655(Constants.MOD_ID, "somewhat_steep"),
        SomewhatSteepMaterialCondition.CODEC.comp_640());

    // Use Fabric to bootstrap the Common mod.
    Constants.LOG.info("Larion World Generation: Registered custom entries");
    CommonClass.init();
  }
}
