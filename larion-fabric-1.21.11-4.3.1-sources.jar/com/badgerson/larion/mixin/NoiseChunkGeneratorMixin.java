package com.badgerson.larion.mixin;

import net.minecraft.class_2246;
import net.minecraft.class_3754;
import net.minecraft.class_5284;
import net.minecraft.class_6350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3754.class)
public class NoiseChunkGeneratorMixin {
  @Inject(method = "createFluidPicker", at = @At("HEAD"), cancellable = true)
  private static void createFluidPicker(class_5284 settings,
      CallbackInfoReturnable<class_6350.class_6565> ci) {
    // This mixin modifies the aquifer generator so that the "bedrock lava
    // level" (in vanilla hardcoded to -54) is instead determined by the world's
    // minimum Y level, allowing for deeper caves without them being flooded.
    // Ideally the lava sea level would be a field in the noise settings
    // like normal sea level, but this is easier to implement
    var lavaSeaLevel = settings.comp_474().comp_173() + 10;
    class_6350.class_6351 lavaFluidStatus = new class_6350.class_6351(lavaSeaLevel, class_2246.field_10164.method_9564());
    int i = settings.comp_479();
    class_6350.class_6351 defaultFluidStatus = new class_6350.class_6351(i, settings.comp_476());
    // AquiferSampler.FluidLevel fluidLevel3 = new
    // AquiferSampler.FluidLevel(DimensionType.MIN_HEIGHT * 2,
    // Blocks.AIR.getDefaultState());
    ci.setReturnValue((x, y, z) -> y < Math.min(lavaSeaLevel, i) ? lavaFluidStatus : defaultFluidStatus);
  }
}
