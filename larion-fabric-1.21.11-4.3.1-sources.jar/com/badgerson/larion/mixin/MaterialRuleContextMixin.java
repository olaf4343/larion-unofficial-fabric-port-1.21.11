package com.badgerson.larion.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.badgerson.larion.MaterialRuleContextExtensions;
import com.badgerson.larion.SomewhatSteepSlopePredicate;
import net.minecraft.class_6686;
import org.spongepowered.asm.mixin.injection.At;


@Mixin(class_6686.class_6694.class)
public abstract class MaterialRuleContextMixin implements MaterialRuleContextExtensions {

  public class_6686.class_6692 somewhatSteepSlopePredicate;

  @Inject(
    method = "<init>",
    at = @At("TAIL")
  )
  public void constructorTail(CallbackInfo ci) {
    somewhatSteepSlopePredicate = new SomewhatSteepSlopePredicate((class_6686.class_6694)(Object)this);
  }

  @Override
  public class_6686.class_6692 getSomewhatSteepSlopePredicate() {
  	return somewhatSteepSlopePredicate;
  }
    
}
