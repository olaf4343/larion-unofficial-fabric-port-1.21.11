package com.badgerson.larion;

import net.minecraft.class_6686;

public interface MaterialRuleContextExtensions {
  public class_6686.class_6692 getSomewhatSteepSlopePredicate();
}
