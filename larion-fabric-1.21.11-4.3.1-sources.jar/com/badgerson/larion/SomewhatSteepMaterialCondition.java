package com.badgerson.larion;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_6686;
import net.minecraft.class_7243;

public enum SomewhatSteepMaterialCondition implements class_6686.class_6693{
  INSTANCE;

  static final class_7243<SomewhatSteepMaterialCondition> CODEC = class_7243.method_42116(MapCodec.unit(INSTANCE));

  @Override
  public class_7243<? extends class_6686.class_6693> method_39064() {
    return CODEC;
  }

  public class_6686.class_6692 apply(class_6686.class_6694 context) {
    return ((MaterialRuleContextExtensions)(Object)context).getSomewhatSteepSlopePredicate();
  }
}
