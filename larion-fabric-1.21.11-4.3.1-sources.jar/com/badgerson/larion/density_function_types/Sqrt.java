package com.badgerson.larion.density_function_types;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_7243;

public record Sqrt(class_6910 df) implements class_6916.class_6932{

    private static final MapCodec<Sqrt> MAP_CODEC = RecordCodecBuilder.mapCodec(
            (instance) -> instance.group(class_6910.field_37059.fieldOf("argument").forGetter(Sqrt::df))
                    .apply(instance, (Sqrt::new)));
    public static final class_7243<Sqrt> CODEC = class_6916.method_41065(MAP_CODEC);

    @Override
    public class_6910 comp_380() {
        return this.df;
    }

    @Override
    public double method_40520(double density) {
        if (density <= 0) {
            return 0;
        }
        return Math.sqrt(density);
    }

    @Override
    public class_6910 method_40469(class_6915 visitor) {
        return new Sqrt(this.df.method_40469(visitor));
    }

    @Override
    public double comp_377() {
        return Math.min(0, Math.sqrt(this.df.comp_377()));
    }

    @Override
    public double comp_378() {
        return Math.max(0, Math.sqrt(this.df.comp_378()));
    }

    @Override
    public class_7243<? extends class_6910> method_41062() {
        return CODEC;
    }
}
