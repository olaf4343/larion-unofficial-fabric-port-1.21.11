// Original credit: https://github.com/klinbee/More-Density-Functions (thanks)
package com.badgerson.larion.density_function_types;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_7243;

public record Sine(class_6910 df) implements class_6916.class_6932 {

    private static final MapCodec<Sine> MAP_CODEC = RecordCodecBuilder.mapCodec((instance) -> instance.group(class_6910.field_37059.fieldOf("argument").forGetter(Sine::df)).apply(instance, (Sine::new)));
    public static final class_7243<Sine> CODEC  = class_6916.method_41065(MAP_CODEC);

    @Override
    public class_6910 comp_380() {
        return this.df;
    }

    @Override
    public double method_40520(double density) {
        return Math.sin(density);
    }

    @Override
    public class_6910 method_40469(class_6915 visitor) {
        return new Sine(this.df.method_40469(visitor));
    }

    @Override
    public double comp_377() {
        return -1;
    }

    @Override
    public double comp_378() {
        return 1;
    }

    @Override
    public class_7243<? extends class_6910> method_41062() {
        return CODEC;
    }
}

