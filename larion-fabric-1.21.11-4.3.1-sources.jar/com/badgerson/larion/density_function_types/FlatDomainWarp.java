package com.badgerson.larion.density_function_types;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_7243;

public record FlatDomainWarp(class_6910 input, class_6910 warpX, class_6910 warpZ)
		implements class_6910 {

	private static final MapCodec<FlatDomainWarp> MAP_CODEC = RecordCodecBuilder.mapCodec((instance) -> instance
			.group(class_6910.field_37059.fieldOf("input").forGetter(FlatDomainWarp::input),
					class_6910.field_37059.fieldOf("warp_x").forGetter(FlatDomainWarp::warpX),
					class_6910.field_37059.fieldOf("warp_z").forGetter(FlatDomainWarp::warpZ))
			.apply(instance, (FlatDomainWarp::new)));
	public static final class_7243<FlatDomainWarp> CODEC = class_6916.method_41065(MAP_CODEC);

	@Override
	public double method_40464(class_6912 context) {
		return input.method_40464(new class_6914(
				context.comp_371() + (int) this.warpX.method_40464(context),
				context.comp_372(),
				context.comp_373() + (int) this.warpZ.method_40464(context)));
	}

	@Override
	public void method_40470(double[] densities, class_6911 provider) {
		provider.method_40478(densities, this);
	}

	@Override
	public class_6910 method_40469(class_6915 visitor) {
		return visitor.apply(
				new FlatDomainWarp(this.input.method_40469(visitor), this.warpX.method_40469(visitor), this.warpZ.method_40469(visitor)));
	}

	@Override
	public double comp_377() {
		return this.input.comp_377();
	}

	@Override
	public double comp_378() {
		return this.input.comp_378();
	}

	@Override
	public class_7243<? extends class_6910> method_41062() {
		return CODEC;
	}
}
