// Original credit: https://github.com/klinbee/More-Density-Functions (thanks)
package com.badgerson.larion.density_function_types;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_6910;
import net.minecraft.class_7243;

public record XCoord() implements class_6910.class_6913 {

    public static final class_7243<XCoord> CODEC = class_7243.method_42116(MapCodec.unit(new XCoord()));

    @Override
    public double method_40464(class_6910.class_6912 context) {
        return Math.min(Math.max(context.comp_371(), comp_377()), comp_378());
    }

    @Override
    public double comp_377() {
        return -30_000_000;
    }

    @Override
    public double comp_378() {
        return 30_000_000;
    }

    public class_7243<? extends class_6910> method_41062() {
        return CODEC;
    }
}
