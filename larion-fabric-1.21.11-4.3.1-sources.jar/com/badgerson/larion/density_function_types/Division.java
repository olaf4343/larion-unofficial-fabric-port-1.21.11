// Original credit: https://github.com/klinbee/More-Density-Functions (thanks)
package com.badgerson.larion.density_function_types;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_7243;

public record Division(class_6910 argument1, class_6910 argument2) implements class_6910 {

    private static final MapCodec<Division> MAP_CODEC = RecordCodecBuilder.mapCodec((instance) -> instance
            .group(class_6910.field_37059.fieldOf("argument1").forGetter(Division::argument1),
                    class_6910.field_37059.fieldOf("argument2").forGetter(Division::argument2))
            .apply(instance, (Division::new)));
    public static final class_7243<Division> CODEC = class_6916.method_41065(MAP_CODEC);

    @Override
    public double method_40464(class_6912 context) {
        double dividendValue = this.argument1.method_40464(context);
        double divisorValue = this.argument2.method_40464(context);

        if (divisorValue == 0) {
            return 0.0;
        }

        double result = dividendValue / divisorValue;

        return result;
    }

    @Override
    public void method_40470(double[] densities, class_6911 provider) {
        provider.method_40478(densities, this);
    }

    @Override
    public class_6910 method_40469(class_6915 visitor) {
        return visitor.apply(new Division(this.argument1.method_40469(visitor), this.argument2.method_40469(visitor)));
    }

    @Override
    public class_6910 argument1() {
        return argument1;
    }

    @Override
    public class_6910 argument2() {
        return argument2;
    }

    @Override
    public double comp_377() {
        if (this.argument2.comp_377() == 0) return 0;
        return this.argument1.comp_377() / this.argument2.comp_377();
    }

    @Override
    public double comp_378() {
        if (this.argument2.comp_378() == 0) return 0;
        return this.argument1.comp_378() / this.argument2.comp_378();
    }

    @Override
    public class_7243<? extends class_6910> method_41062() {
        return CODEC;
    }
}
