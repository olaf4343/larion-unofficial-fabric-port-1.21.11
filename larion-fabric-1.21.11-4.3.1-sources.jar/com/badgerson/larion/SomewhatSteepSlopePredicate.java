package com.badgerson.larion;

import net.minecraft.class_2791;
import net.minecraft.class_2902;
import net.minecraft.class_6686;

public class SomewhatSteepSlopePredicate extends class_6686.class_6773{
	public SomewhatSteepSlopePredicate(class_6686.class_6694 context) {
		super(context);
	}

	@Override
	protected boolean method_39074() {

  int x = this.field_35623.field_35609 & 15;
  int z = this.field_35623.field_35610 & 15;

  class_2791 chunk = this.field_35623.field_35605;

  int here = chunk.method_12005(class_2902.class_2903.field_13194, x, z);

  final int SOMEWHAT_STEEP_THRESHOLD = 1;

	int south = chunk.method_12005(class_2902.class_2903.field_13194, x, Math.max(z - 1, 0));
	if (here - south > SOMEWHAT_STEEP_THRESHOLD) {
		return true;
	} else {
		int north = chunk.method_12005(class_2902.class_2903.field_13194, x, Math.min(z + 1, 15));
		if (here - north > SOMEWHAT_STEEP_THRESHOLD) {
			return true;
		} else {

			int west = chunk.method_12005(class_2902.class_2903.field_13194, Math.max(x - 1, 0), z);
			if (here - west > SOMEWHAT_STEEP_THRESHOLD) {
				return true;
			} else {
				int east = chunk.method_12005(class_2902.class_2903.field_13194, Math.min(x + 1, 15), z);
				return here - east > SOMEWHAT_STEEP_THRESHOLD;
			}
		}
	}
  }
}
